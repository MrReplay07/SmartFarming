#ifndef ANTO_COMMON_H
#define ANTO_COMMON_H

#define ANTO_VER    "v0.7.2"

#endif /* ifndef ANTO_COMMON_H */
